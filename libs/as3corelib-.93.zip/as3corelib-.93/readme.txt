corelib ActionScript 3 Library
Release version .93

Project Homepage:
http://code.google.com/p/as3corelib/